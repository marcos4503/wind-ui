Componente BUTTON

O QUE ESTE COMPONENTE FAZ?

Este componente apenas exibe um botão clicável no local desejado.