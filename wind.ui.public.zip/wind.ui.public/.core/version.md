=============================
        Wind UI Version      
=============================

- 0.0.1
    - Wind UI teve seu lançamento. Esta é a primeira versão e o mesmo se encontra em estado beta de testes.

O Wind UI foi desenvolvido por Marcos Tomaz em 2020.