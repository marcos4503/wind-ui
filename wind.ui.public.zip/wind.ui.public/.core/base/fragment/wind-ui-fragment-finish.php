<!-- ========================= Wind UI End of Fragment Renderer base code ========================= -->
<!-- This Fragment change client title on load -->
<script id="windUiFragmentRendererFinalScript" type="text/javascript">
    WindUiJs.changeCurrentClientTitle("<?php echo(WindUiFragmentRenderer::$thisFragmentTitle); ?>");
</script>