<html>
    <head>
        <title>Erro JavaScript - Wind UI</title>
    </head>
    <body>
        <center>
            <h2>Erro JavaScript</h2>
            <hr>
            Esta aplicação depende de JavaScript para funcionar. Por favor, habilite o JavaScript do seu navegador e tente acessar o site novamente.
        </center>
    </body>
</html>